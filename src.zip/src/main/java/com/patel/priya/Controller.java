package com.patel.priya;

import com.patel.priya.exceptions.SetOfStringException;
import com.patel.priya.exceptions.SetOfStringNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.Set;

@RestController
public class Controller {

    @Autowired
    Service service;

    @PostMapping(value = "/lcs", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Response processLcs(@RequestBody Request request) {
        if (request.getSetOfStrings() == null || request.getSetOfStrings().get(0) == null
                || request.getSetOfStrings().get(0).getValue() == null || request.getSetOfStrings().isEmpty()) {
            throw new SetOfStringNotFoundException("SetOfString must NOT be empty!");
        }

        Set<String> setOfStrings = new HashSet<>();
        request.getSetOfStrings().forEach(setOfString -> setOfStrings.add(setOfString.getValue()));

        if (setOfStrings.size() != request.getSetOfStrings().size()) {
            throw new SetOfStringException("SetOfStrings must be a Set!");
        }

        request.getSetOfStrings().forEach(setOfString -> {

        });

        return service.processLcs(request);
    }
}
