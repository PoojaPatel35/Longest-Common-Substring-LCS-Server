package com.patel.priya;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.patel.priya.exceptions.JsonParserException;
import com.patel.priya.exceptions.SetOfStringException;
import com.patel.priya.exceptions.SetOfStringNotFoundException;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class CustomRestExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(value = {SetOfStringNotFoundException.class})
    protected ResponseEntity<Object> notFoundException(SetOfStringNotFoundException ex, WebRequest request) {
        return handleExceptionInternal(ex, ex.getMessage(), new HttpHeaders(), HttpStatus.NOT_FOUND, request);
    }

    @ExceptionHandler(value = {JsonParserException.class})
    protected ResponseEntity<Object> jsonParseException(RuntimeException ex, WebRequest request) {
        return handleExceptionInternal(ex, "The request must be in JSON format!", new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(value = {SetOfStringException.class})
    protected ResponseEntity<Object> setOfStringNotFoundExceptionException(SetOfStringException ex, WebRequest request) {
        return handleExceptionInternal(ex, ex.getMessage(), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }
}
