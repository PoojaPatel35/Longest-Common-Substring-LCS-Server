package com.patel.priya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PriyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PriyaApplication.class, args);
	}

}
