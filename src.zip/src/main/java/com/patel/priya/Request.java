package com.patel.priya;

import java.util.List;

public class Request {
    private List<SetOfString> setOfStrings;

    protected static class SetOfString {
        private String value;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public List<SetOfString> getSetOfStrings() {
        return setOfStrings;
    }

    public void setSetOfStrings(List<SetOfString> setOfStrings) {
        this.setOfStrings = setOfStrings;
    }
}
