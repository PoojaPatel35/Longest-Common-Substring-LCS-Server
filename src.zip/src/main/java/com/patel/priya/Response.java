package com.patel.priya;

import java.util.Map;

public class Response {
    Map<String, String> lsc;

    public static class Lsc {
        private String value;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public Map<String, String> getLsc() {
        return lsc;
    }

    public void setLsc(Map<String, String> lsc) {
        this.lsc = lsc;
    }
}
