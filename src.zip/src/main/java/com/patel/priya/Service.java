package com.patel.priya;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

@org.springframework.stereotype.Service
public class Service {

    public Response processLcs(Request request) {
        List<Map<String, String>> mapList = new ArrayList<>();

        request.getSetOfStrings().forEach(setOfString -> mapList.add(generateAllPossibleVariants(setOfString.getValue())));
        Map<Integer, List<String>> mapSearchResult = searchLongestValue(mapList);

        return buildResponseObject(mapSearchResult);
    }

    private Response buildResponseObject(Map<Integer, List<String>> mapSearchResult) {
        Response response = new Response();
        Map<String, String> result = new HashMap<>();
        final int[] maxIndex = {0};

        mapSearchResult.forEach((key, listOfWords) -> {
            if (maxIndex[0] < key) {
                maxIndex[0] = key;
            }
        });

        List<String> sortedList = mapSearchResult.get(maxIndex[0]);
        Collections.sort(sortedList);
        sortedList.forEach(word -> result.put("value", word));
        response.setLsc(result);

        return response;
    }

    private Map<Integer, List<String>> searchLongestValue(List<Map<String, String>> mapList) {
        Map<Integer, List<String>> longestWordMap = new HashMap<>();

        if (!mapList.isEmpty()) {
            AtomicBoolean isLongestWordFound = new AtomicBoolean(false);

            mapList.get(0).forEach((key, word) -> {
                for (int i = 1; i < mapList.size(); i++) {
                    isLongestWordFound.set(mapList.get(i).containsKey(key));
                }

                if (isLongestWordFound.get()) {
                    if (longestWordMap.containsKey(word.length())) {
                        List<String> currentWords = longestWordMap.get(word.length());
                        currentWords.add(word);
                        longestWordMap.put(word.length(), currentWords);
                    } else {
                        List<String> currentWords = new ArrayList<>();
                        currentWords.add(word);
                        longestWordMap.put(word.length(), currentWords);
                    }
                }
            });
        }

        return longestWordMap;
    }

    private Map<String, String> generateAllPossibleVariants(String str) {
        Map<String, String> variants = new HashMap<>();
        char[] chars = str.toCharArray();
        int step = 1;

        while (step != chars.length) {
            for (int i = 0; i + step <= chars.length; i++) {
                String result = str.substring(i, i + step);
                variants.put(result, result);
            }
            step++;
        }

        return variants;
    }
}
