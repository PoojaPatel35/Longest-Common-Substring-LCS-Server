package com.patel.priya.exceptions;

public class SetOfStringException extends RuntimeException {
    public SetOfStringException(String message) {
        super(message);
    }
}
