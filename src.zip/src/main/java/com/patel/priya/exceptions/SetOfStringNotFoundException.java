package com.patel.priya.exceptions;

public class SetOfStringNotFoundException extends RuntimeException {
    public SetOfStringNotFoundException(String message) {
        super(message);
    }
}
