package com.patel.priya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
